// 这是一个简单的组件，用于显示鼠标的位置信息
// 首先导入React和useState，以及定义MouseProps接口
import React, { useEffect, useState } from 'react'
interface MouseProps {
  x: number,
  y: number,
  positions: number,
  setPositions: () => void
}

// 定义Mouse组件
const Mouse: React.FC<MouseProps> = () => {
  const [positions, setPositions] = useState({x: 0, y: 0});
  
  // 使用useEffect来监听鼠标点击事件，并更新位置信息
  useEffect(()=>{
    //创建一个回调函数
    const updateMouse = (e: MouseEvent)=>{
      // console.log('inner');//什么时候调用
      setPositions({x:e.clientX,y:e.clientY})
    }
    document.addEventListener('click', updateMouse)
    //清除
    return() => {
      document.removeEventListener('click', updateMouse)
    }
  },[])

  // 在页面上显示鼠标位置信息
  return (
    <>
      <p>X:{positions.x},Y:{positions.y}</p>
    </>
  )
}

// 导出Mouse组件
export default Mouse