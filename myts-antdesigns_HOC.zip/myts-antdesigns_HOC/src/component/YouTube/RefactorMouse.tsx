import React from 'react'
/**
 * 
 * @returns 
 * 前面两节课程使用Hook从组件中提取逻辑状态，使得这些逻辑可以单独测试并且复用；Hook使你无需修改组件结构的情况下复用状态逻辑，这使得在组件内的社区内共享Hook变得更便体，这也是Hook最吸引人的特性
 */


//将组件逻辑提取到可重用的函数
//使用自定义Hook抽象鼠标跟踪器
const RefactorMouse = () => {
  return (
    <div>RefactorMouse</div>
  )
}

export default RefactorMouse