import React, { useEffect, useState } from 'react'

//控制UseEffect的执行,
//修改前面两个离子的代码
const MouseTracker: React.FC = () => {
  const [positions, setPositions] = useState({ x: 0, y: 0 });
  //等待渲染结束，做的其它事情
  useEffect(() => {
    console.log('add effect添加效果', positions.x);
    const updateMouse = (e: MouseEvent) => {
      console.log('inner');
      setPositions({ x: e.clientX, y: e.clientY })
    }
    document.addEventListener('click', updateMouse);
    return () => {
      console.log('remove effect移除效果', positions.x);
      document.removeEventListener('click', updateMouse)
    }
  },[positions.x, positions.y]);//添加依赖项
  console.log('before render渲染前', positions.x);
  return (
    <>
      <p>X:{positions.x},Y:{positions.y}</p>
    </>
  )
}

export default MouseTracker