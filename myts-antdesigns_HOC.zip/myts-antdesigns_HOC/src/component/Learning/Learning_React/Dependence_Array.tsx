import React, { useEffect, useState } from 'react'
//React在状态发生变化时重新渲染组件树
//定义DependenceProps接口，包含4个属性
interface DependenceProps {
    val: string,
    set: () => void,
    phrase: string | undefined,
    setPhrase: () => void
}
//定义Dependence_Array组件，接受DependenceProps接口作为参数
const Dependence_Array: React.FC<DependenceProps> = () => {
    const [val, setVal] = useState("");// 使用 useState 定义 val 和 phrase 两个状态
    const [phrase, setPhrase] = useState("example phrase");

    const createPhrase = () => {//定义createPhrase函数，用于更新phrase状态
        setPhrase(val)
    };

    useEffect(() => {//监听val状态的变化，并打印当前输入的值
        // console.log(`typing "${val}"`);
    },[val])

    useEffect(()=>{//监听phrase状态的变化，并打印当前保存的短语
        // console.log(`saved phrase "${phrase}"`);
    },[phrase])
    return (//渲染输入框和按钮
        <>
            <label>Favorite phrase:</label>
            <input 
                value={val} 
                placeholder={phrase}
                onChange={e => setVal(e.target.value)}
            />
            <button onClick={createPhrase}>send</button>
            <span>{val}</span>
        </>
    )
}

export default Dependence_Array