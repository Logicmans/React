import React, { useState, useEffect } from "react";

interface CheckboxProps {
    checked: boolean; // 复选框是否选中的状态
    setChecked: () => void; // 设置复选框选中状态的函数
}

// 1.创建复选框组件
const Checkbox: React.FC<CheckboxProps> = ({ checked, setChecked }) => {
    // 当复选框状态改变时触发
    // useEffect(() => {
    //     alert(`checked: ${checked.toString()}`); // 弹出提示框显示复选框的选中状态
    // }, [checked]);
    useEffect(()=>{
        // console.log('checkbox-value', checked);
    })
    return (
        <>
            <input
                type="checkbox"
                checked={checked}
                onChange={() => setChecked()} // 当复选框状态改变时调用设置复选框选中状态的函数
            />
            {checked ? "已选中" : "未选中"} 
        </>
    );
};

// 应用程序组件
const App: React.FC = () => {
    const [checked, setChecked] = useState<boolean>(false); // 初始化复选框的选中状态为未选中

    return <Checkbox checked={checked} setChecked={() => setChecked((prevChecked) => !prevChecked)} />; // 渲染复选框组件并传入选中状态和设置选中状态的函数
};

export default App;
