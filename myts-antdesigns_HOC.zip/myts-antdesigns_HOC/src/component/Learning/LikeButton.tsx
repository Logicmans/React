import React, { useEffect, useState } from 'react'
interface LikeButtonProps {
    like: number,
    on: boolean,
    setLike: () => void,
    setOn: () => void,
}
const LikeButton: React.FC<LikeButtonProps> = () => {
    const [like, setLike] = useState(0);
    const [on, setOn] = useState(true);
    useEffect(() => {
        document.title = `点击了${like}次`
    });
    return (
        <>
            <h2>赞：{like}</h2>
            <button onClick={() => { setLike(like + 1)}}>👍</button>
            <button onClick={() => { setLike(like - 1) }}>👎</button>
            <button onClick={() => { setOn(!on) }}>{on ? 'ON' : 'OFF'}</button>
        </>

    )
}

export default LikeButton