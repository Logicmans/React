import React, { useState } from 'react'
import LikeButton from './component/Learning/LikeButton' // 导入 LikeButton 组件
import CheckBox from './component/Learning/CheckBox' // 导入 CheckBox 组件
import Mouse from './component/YouTube/Mouse' // 导入 Mouse 组件
import Dependence from './component/Learning/Learning_React/Dependence_Array' // 导入 Dependence 组件
import MouseTracker from './component/YouTube/MouseTracker' // 导入 MouseTracker 组件
import withLoader from './hooks/withLoader' // 导入高阶组件 withLoader

// 定义接口 IShowResult，用于描述 API 返回的数据结构
interface IShowResult {
  message: string; // 图片的 URL
  status: string; // 状态信息
}

// DogShow 组件，显示狗狗图片和状态
const DogShow: React.FC<{ data: IShowResult }> = ({ data }) => {
  return (
    <>
      <h2>Dog show: {data.status}</h2> {/* 显示状态信息 */}
      <img src={data.message} alt="Dog" /> {/* 显示狗狗图片 */}
    </>
  )
}

// 主应用程序组件 App
const App: React.FC = () => {
  const [show, setShow] = useState(true); // 定义状态 show，初始值为 true

  // 使用 withLoader 高阶组件包装 DogShow 组件，传入 API 地址
  const WrappedDogShow = withLoader(DogShow, 'https://dog.ceo/api/breeds/image/random')

  return (
    <div>
      <header className='App-header'>
        <WrappedDogShow/><hr/> {/* 显示包装后的 DogShow 组件 */}
        
        {/* LikeButton 组件 */}
        <LikeButton 
          like={0} 
          setLike={() => { throw new Error('Function not implemented.') }} 
          on={false} 
          setOn={() => { throw new Error('Function not implemented.') }} 
        /><br />

        {/* CheckBox 组件 */}
        <CheckBox /><br />

        {/* Mouse 组件 */}
        <Mouse 
          x={0} 
          y={0} 
          positions={0} 
          setPositions={() => { throw new Error('Function not implemented.') }} 
        /><hr />

        {/* Dependence 组件 */}
        <Dependence 
          val={''} 
          set={() => { throw new Error('Function not implemented.') }} 
          phrase={undefined} 
          setPhrase={() => { throw new Error('Function not implemented.') }} 
        /><hr />

        {/* 手动控制 MouseTracker 的按钮 */}
        <p>
          <button onClick={() => { setShow(!show) }}>手动</button>
        </p>

        {/* 根据 show 状态决定是否显示 MouseTracker 组件 */}
        {show && <MouseTracker />}
      </header>
    </div>
  )
}

export default App; // 导出 App 组件