import { useState, useEffect } from 'react';
import axios from 'axios';

// 定义钩子的参数接口
interface useURLLoaderProps {
  url: string; // 请求的URL
  // deps?: React.DependencyList; // 可选的依赖数组
  deps?:any[];
}

// 自定义钩子，使用泛型 T 以适应不同的数据类型
const useURLLoader = <T,>({ url, deps }: useURLLoaderProps): [T | null, boolean] => {
  const [data, setData] = useState<T | null>(null); // 存储获取的数据，初始为 null
  const [loading, setLoading] = useState<boolean>(false); // 存储加载状态，初始为 false
  
  useEffect(() => {
    // 定义一个异步函数来获取数据
    const fetchData = async () => {
      setLoading(true); // 设置加载状态为 true
      try {
        const result = await axios.get<T>(url); // 发送 GET 请求
        setData(result.data); // 成功后设置数据
      } catch (error) {
        console.error("获取数据时出错:", error); // 捕获错误并打印
        setData(null); // 可选：在出错时重置数据
      } finally {
        setLoading(false); // 无论成功与否，最后都设置加载状态为 false
      }
    };

    fetchData(); // 调用获取数据的函数
    
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, deps]); // 依赖数组，确保在 url 或者 deps 变化时重新执行

  return [data, loading]; // 返回数据和加载状态
};

export default useURLLoader; // 导出钩子